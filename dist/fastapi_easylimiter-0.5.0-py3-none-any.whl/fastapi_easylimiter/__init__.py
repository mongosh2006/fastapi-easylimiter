# __init__.py
from .middleware import RateLimitMiddleware

__version__ = "0.5.0"
__all__ = ["RateLimitMiddleware"]
